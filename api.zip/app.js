// ℹ️ Gets access to environment variables/settings
// https://www.npmjs.com/package/dotenv
require("dotenv").config();

// ℹ️ Connects to the database
require("./db");

// Handles http requests (express is node js framework)
// https://www.npmjs.com/package/express
const express = require("express");
const morgan = require("morgan");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const { isAuthenticated } = require("./middleware/jwt.middleware");
const app = express();
const frontendUrl = process.env.FRONTEND_URL;

// ℹ️ MIDDLEWARES DEVEM VIR ANTES DAS ROTAS
// Use morgan middleware for logging
app.use(morgan('dev'));

/* // Use cors middleware (removida a barra extra)
app.use(cors({origin: [frontendUrl]})); */

// Use cookieParser middleware
app.use(cookieParser());

const webhooksRoutes = require("./webhooks/webhooks.routes");
app.use("/api/webhooks", webhooksRoutes);

require("./config")(app);

// 👇 Start handling routes here (APÓS os middlewares)
const indexRoutes = require("./routes/index.routes");
app.use("/api", indexRoutes);

const authRoutes = require("./routes/auth.routes");
app.use("/auth", authRoutes);

const cardsRoutes = require("./routes/cards.routes");
app.use("/api", cardsRoutes);

const emailRoutes = require("./routes/email.routes");
app.use("/api/email", emailRoutes);

const analyticsRoutes = require("./routes/analytics.routes");
app.use("/api", analyticsRoutes);

const paymentRoutes = require("./routes/payment.routes");
app.use("/api/payments", paymentRoutes);




require("./error-handling")(app);

module.exports = app;