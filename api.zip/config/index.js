const express = require("express");
const logger = require("morgan");
const cookieParser = require("cookie-parser");
const cors = require("cors");

const FRONTEND_URL = process.env.FRONTEND_URL;

module.exports = (app) => {
  app.set("trust proxy", 1);

  const allowedOrigins = [FRONTEND_URL, "http://localhost:5173", "http://localhost:5174"];

  // Middleware CORS principal
  app.use(
    cors({
      origin: function (origin, callback) {
        // Permitir requests sem "origin" (ex: Postman)
        if (!origin) return callback(null, true);
        if (allowedOrigins.includes(origin)) {
          return callback(null, true);
        } else {
          console.warn(`🚫 CORS bloqueado para origem: ${origin}`);
          return callback(new Error("Not allowed by CORS"));
        }
      },
      credentials: true,    // permite cookies
    })
  );

  // Preflight para todos os endpoints
  app.options("*", cors({
    origin: FRONTEND_URL,
    credentials: true,
  }));

  app.use(logger("dev"));
  app.use(express.json());
  app.use(express.urlencoded({ extended: false }));
  app.use(cookieParser());
};
