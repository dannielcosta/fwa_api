const router = require("express").Router();
const stripe = require("../stripe/stripe.config");
const bodyParser = require("body-parser");
const pool = require("../db");
const {
  generatePhysicalCardPDF,
} = require("../services/pdf/generatePhysicalCardPDF.js");
const { sendEmail } = require("../services/email/email.service");

router.post(
  "/stripe-webhook",
  bodyParser.raw({ type: "application/json" }),
  async (req, res) => {
    const sig = req.headers["stripe-signature"];
    let event;

    try {
      event = stripe.webhooks.constructEvent(
        req.body,
        sig,
        process.env.STRIPE_WEBHOOK_SECRET
      );
    } catch (err) {
      console.error("❌ Webhook signature error:", err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event.type === "checkout.session.completed") {
      const session = event.data.object;

      const userId = String(session.metadata.userId); // UUID-safe
      const planId = session.metadata.planId;

      let cardIds = [];
      try {
        cardIds = JSON.parse(session.metadata.cardIds || "[]").map(String);
      } catch (e) {
        console.error("❌ Failed to parse cardIds:", e);
      }

      if (cardIds.length === 0) {
        console.error("❌ No cardIds to activate");
        return res.status(200).json({ received: true });
      }

      try {
        await pool.query(
          `INSERT INTO payments (
        user_id, plan_id, amount, stripe_session_id,
        stripe_payment_intent, stripe_status, payment_type, metadata
      ) VALUES ($1,$2,$3,$4,$5,'paid','purchase',$6)
      ON CONFLICT (stripe_session_id) DO NOTHING`,
          [
            userId,
            planId,
            session.amount_total / 100,
            session.id,
            session.payment_intent,
            JSON.stringify(session.metadata),
          ]
        );

        const cardsRes = await pool.query(
          `SELECT id, type, design_mode, design_meta
   FROM business_cards
   WHERE id = ANY($1::text[])`,
          [cardIds]
        );

        for (const card of cardsRes.rows) {
          let pdfUrl = null;

          // 🖨️ DESIGN CREATED IN EDITOR

          if (
            card.design_mode.includes("designed") ||
            card.design_mode === "designed"
          ) {
            console.log("designed");
            const pdfBuffer = await generatePhysicalCardPDF(card.design_meta);

            const fs = require("fs");
            const path = require("path");
            const os = require("os");

            if (card.design_mode === "designed") {
              const pdfBuffer = await generatePhysicalCardPDF(card.design_meta);

              const downloadsDir = path.join(os.homedir(), "Downloads");
              const pdfPath = path.join(downloadsDir, `card_${card.id}.pdf`);

              fs.writeFileSync(pdfPath, pdfBuffer);
            }
          }

          // 📎 USER UPLOADED PDF
          if (
            card.design_mode.includes("uploaded") ||
            card.design_mode === "uploaded"
          ) {
            // already stored earlier (no-op)
          }

          let pdfBuffer;

          try {
            pdfBuffer = await generatePhysicalCardPDF(card.design_meta);
          } catch (e) {
            console.error("PDF ERROR:", e);
            continue;
          }

          console.log("SENDING EMAIL");

          await sendEmail({
            to: "suporte@nfc-me.pt",
            subject: `Cartão NFC para impressão (#${card.id})`,
            text: `Segue em anexo o PDF do cartão físico.\n\nCard ID: ${card.id}`,
            attachments: [
              {
                filename: `card_${card.id}.pdf`,
                content: pdfBuffer,
                contentType: "application/pdf",
              },
            ],
          });

          await pool.query(
            `UPDATE business_cards
              SET status = 'active',
                  design_meta = NULL
              WHERE id = $1`,
            [card.id]
          );
        }

        console.log(
          "design mode",
          cardsRes.rows.map((card) => card.design_mode)
        );

        console.log(
          "✅ Activated cards:",
          cardsRes.rows.map((card) => card.id)
        );

        await pool.query(`UPDATE users SET status = 'active' WHERE id = $1`, [
          userId,
        ]);
      } catch (err) {
        console.error("❌ DB error in webhook:", err);
      }
    }

    res.status(200).json({ received: true });
  }
);

module.exports = router;
