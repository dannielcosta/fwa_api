const express = require("express");
const router = express.Router();
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const pool = require("../db/index"); 
const { isAuthenticated } = require("../middleware/jwt.middleware.js");



const saltRounds = 10;

// POST /auth/signup
router.post("/signup", async (req, res, next) => {
  const { email, password, firstname, lastname, phone, type, status, company } = req.body;

  if (email === "" || password === "" || firstname === "" || lastname === "") {
    return res.status(400).json({ message: "Provide email, password, firstname and lastname" });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ message: "Provide a valid email address." });
  }

  const passwordRegex = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
  if (!passwordRegex.test(password)) {
    return res.status(400).json({
      message:
        "Password must have at least 6 characters and contain at least one number, one lowercase and one uppercase letter.",
    });
  }

  try {
    const existingUser = await pool.query("SELECT * FROM users WHERE email = $1", [email]);
    if (existingUser.rows.length > 0) {
      return res.status(400).json({ message: "User already exists." });
    }

    const salt = bcrypt.genSaltSync(saltRounds);
    const hashedPassword = bcrypt.hashSync(password, salt);

    const result = await pool.query(
      "INSERT INTO users (email, password, firstname, lastname, phone, type, status, company) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id, email, firstname, lastname, phone, type",
      [email, hashedPassword, firstname, lastname, phone, type, status || "pending", company]
    );

    const user = result.rows[0];
      const token = jwt.sign(
    { id: user.id, email: user.email, type: user.type },
    process.env.TOKEN_SECRET,  // chave secreta definida no .env
    { expiresIn: "1h" }      // expira em 1 hora
  );

res.status(201).json({
  token,
  user
});

  } catch (err) {
    next(err);
  }
});

// POST /auth/login
router.post("/login", async (req, res, next) => {
  const { email, password } = req.body;


  if (email === "" || password === "") {
    return res.status(400).json({ message: "Provide email and password." });
  }

  try {
    const result = await pool.query("SELECT * FROM users WHERE email = $1", [email]);
    const foundUser = result.rows[0];

    
    if (!foundUser) {
      return res.status(401).json({ message: "User not found." });
    }

    if (foundUser.status !== "active") {
      return res.status(403).json({ message: "User is not active." });
    }

    const passwordCorrect = bcrypt.compareSync(password, foundUser.password);

    if (!passwordCorrect) {
      return res.status(401).json({ message: "Unable to authenticate the user" });
    }

    if (passwordCorrect) {
      
      const { id, email, firstname, lastname, phone, type, status } = foundUser;
      const payload = { id, email, firstname, lastname, phone, type, status };

      const authToken = jwt.sign(payload, process.env.TOKEN_SECRET, {
        algorithm: "HS256",
        expiresIn: "6h",
      });

      
      // Retorna o token e o tipo do usuário
      res.status(200).json({ 
        authToken, 
        type: type,
        user: { id, email, firstname, lastname, phone, type, status }
      });
    } else {
      res.status(401).json({ message: "Unable to authenticate the user" });
    }
  } catch (err) {
    console.error("Erro no login:", err);
    next(err);
  }
});

// GET /auth/verify
router.get("/verify", isAuthenticated, (req, res, next) => {
  res.status(200).json(req.payload);
});

module.exports = router;