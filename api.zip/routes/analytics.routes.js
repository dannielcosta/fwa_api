const express = require("express");
const router = express.Router();
const pool = require("../db");
const { isAuthenticated } = require("../middleware/jwt.middleware.js");

const hasPermission = (req, res, next) => {
  if (!req.payload) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  const userPayload = req.payload;

  if (req.payload.type === "admin" || req.payload.type === "gestor") {
    next();
  } else {
    res.status(403).json({ message: "Access denied" });
  }
  } ;

// GET /api/analytics/stats?period=monthly&card_id=xyz
router.get("/analytics-stats/:cardId?", isAuthenticated, hasPermission, async (req, res) => {
  const { cardId } = req.params;
  const { period = "daily" } = req.query;

  try {
    // 🔹 Define os parâmetros de acordo com o período
    const cfg = {
      daily:      { step: "1 day",    buckets: 30, /* 30 dias */        trunc: "day",     label: "DD/MM"        },
      weekly:     { step: "1 week",   buckets: 12, /* 12 semanas */     trunc: "week",    label: "IYYY-IW"      },
      monthly:    { step: "1 month",  buckets: 12, /* 12 meses */       trunc: "month",   label: "YYYY-MM"      },
      quarterly:  { step: "3 months", buckets: 8,  /* 8 trimestres */   trunc: "quarter", label: "YYYY \"Q\"Q"  },
      yearly:     { step: "1 year",   buckets: 5,  /* 5 anos */         trunc: "year",    label: "YYYY"         },
    }[period] ||  { step: "1 month",  buckets: 12, /* 12 meses */       trunc: "month",   label: "YYYY-MM"      };

    let query;
    let params;

    // 🔹 Se existir cardId, inclui o filtro e o parâmetro
    if (cardId) {
      query = `
        WITH bounds AS (
          SELECT 
            (DATE_TRUNC($1, NOW()) - ($2::int - 1) * ($3::text)::interval) AS start_ts,
            DATE_TRUNC($1, NOW())                                          AS end_ts
        ),
        series AS (
          SELECT generate_series(b.start_ts, b.end_ts, ($3::text)::interval) AS bucket_start
          FROM bounds b
        ),
        raw AS (
          SELECT
            DATE_TRUNC($1, last_update) AS bucket_start,
            SUM(total_reads)::bigint AS reads
          FROM card_read_stats crs
          WHERE crs.card_id = $4::text
            AND last_update >= (SELECT start_ts FROM bounds)
            AND last_update <  (SELECT end_ts FROM bounds) + ($3::text)::interval
          GROUP BY 1
        )
        SELECT 
          TO_CHAR(s.bucket_start, $5) AS label,
          COALESCE(r.reads, 0)::bigint AS reads
        FROM series s
        LEFT JOIN raw r ON r.bucket_start = s.bucket_start
        ORDER BY s.bucket_start ASC;
      `;
      params = [cfg.trunc, cfg.buckets, cfg.step, cardId, cfg.label];
    } 
    // 🔹 Caso contrário, remove o filtro e o parâmetro $4
    else {
      query = `
        WITH bounds AS (
          SELECT 
            (DATE_TRUNC($1, NOW()) - ($2::int - 1) * ($3::text)::interval) AS start_ts,
            DATE_TRUNC($1, NOW())                                          AS end_ts
        ),
        series AS (
          SELECT generate_series(b.start_ts, b.end_ts, ($3::text)::interval) AS bucket_start
          FROM bounds b
        ),
        raw AS (
          SELECT
            DATE_TRUNC($1, last_update) AS bucket_start,
            SUM(total_reads)::bigint AS reads
          FROM card_read_stats crs
          WHERE last_update >= (SELECT start_ts FROM bounds)
            AND last_update <  (SELECT end_ts FROM bounds) + ($3::text)::interval
          GROUP BY 1
        )
        SELECT 
          TO_CHAR(s.bucket_start, $4) AS label,
          COALESCE(r.reads, 0)::bigint AS reads
        FROM series s
        LEFT JOIN raw r ON r.bucket_start = s.bucket_start
        ORDER BY s.bucket_start ASC;
      `;
      params = [cfg.trunc, cfg.buckets, cfg.step, cfg.label];
    }


    const { rows } = await pool.query(query, params);

    res.json(rows.map(r => ({
      label: r.label,
      reads: Number(r.reads),
    })));
  } catch (err) {
    console.error("❌ Erro analytics-stats:", err);
    res.status(500).json({ error: "Erro interno do servidor" });
  }
});






// GET /api/analytics/top?limit=5
router.get("/analytics-top", isAuthenticated, hasPermission, async (req, res) => {
  const { limit = 5 } = req.query;

  try {
    const query = `
      SELECT 
        bc.id, 
        bc.first_name, 
        bc.last_name, 
        bc.company, 
        SUM(crs.total_reads) AS total_reads
      FROM card_read_stats crs
      JOIN business_cards bc ON crs.card_id = bc.id
      GROUP BY bc.id
      ORDER BY total_reads DESC
      LIMIT $1;
    `;

    const result = await pool.query(query, [limit]);
    res.json(result.rows);
  } catch (err) {
    console.error("Erro ao buscar top cartões:", err);
    res.status(500).json({ error: "Erro ao buscar top cartões" });
  }
});

// GET /api/analytics/locations?card_id=xyz
router.get("/analytics-locations", isAuthenticated, hasPermission, async (req, res) => {
  const { card_id } = req.query;

  try {
    const query = `
      SELECT card_id, latitude, longitude, created_at
      FROM card_location
      ${card_id ? "WHERE card_id = $1" : ""}
      ORDER BY created_at DESC
      LIMIT 200;
    `;

    const result = await pool.query(query, card_id ? [card_id] : []);
    res.json(result.rows);
  } catch (err) {
    console.error("Erro ao buscar localizações:", err);
    res.status(500).json({ error: "Erro ao buscar localizações" });
  }
});


module.exports = router;    