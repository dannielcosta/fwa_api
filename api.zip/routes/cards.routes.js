const express = require("express");
const router = express.Router();
const pool = require("../db");
const { isAuthenticated } = require("../middleware/jwt.middleware.js");

const multer = require("multer");
const { storage } = require("../cloudinary"); // importar storage do Cloudinary
const cloudinary = require("cloudinary").v2;
const upload = multer({ storage });

let coverUrl;

const exportPdf = () => {
  // Lógica para exportar PDF
  console.log("Exportando PDF...");
};

const hasPermission = (req, res, next) => {
  if (!req.payload) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  const userPayload = req.payload;

  if (req.payload.type === "admin" || req.payload.type === "gestor") {
    next();
  } else {
    res.status(403).json({ message: "Access denied" });
  }
};

//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// USER ROUTES
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// GET REQUESTS
//
//

// GET /api/cards → lista todos os cartões do user autenticado
router.get("/cards", isAuthenticated, hasPermission, async (req, res, next) => {
  try {
    const userId = req.payload.id;
    const userType = req.payload.type;

    const baseQuery = `
      SELECT 
        bc.*, 
        bcl.review,
        bcl.facebook,
        bcl.website,
        bcl.instagram,
        bcl.linkedin,
        COALESCE(SUM(CAST(crs.total_reads AS INTEGER)), 0) AS total_reads
      FROM business_cards bc
      LEFT JOIN business_cards_links bcl ON bc.id = bcl.business_card_id
      LEFT JOIN card_read_stats crs ON bc.id = crs.card_id
      ${userType === "admin" ? "" : "WHERE bc.owner_id = $1"}
      GROUP BY bc.id, bcl.review, bcl.facebook, bcl.website, bcl.instagram, bcl.linkedin
    `;

    const result = await pool.query(
      baseQuery,
      userType === "admin" ? [] : [userId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erro ao buscar cartões:", err);
    next(err);
  }
});

router.get("/cards/:iD", async (req, res, next) => {
  try {
    const { iD } = req.params;
    const { lat, lon } = req.query; // Coordenadas opcionais (enviadas pelo frontend)

    // 1️⃣ Buscar o cartão e seus links
    const query = `
      SELECT 
        bc.*, 
        bcl.review,
        bcl.facebook,
        bcl.standvirtual,
        bcl.website,
        bcl.instagram,
        bcl.olx,
        bcl.location,
        bcl.linkedin
      FROM business_cards bc
      LEFT JOIN business_cards_links bcl ON bc.id = bcl.business_card_id
      WHERE bc.id = $1
    `;

    const result = await pool.query(query, [iD]);
    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Card not found" });
    }

    const row = result.rows[0];

    // 2️⃣ Atualizar estatísticas de leitura mensal
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth() + 1;

    await pool.query(
      `
  INSERT INTO card_read_stats (card_id, year, month, date, total_reads, last_update)
  VALUES ($1, EXTRACT(YEAR FROM CURRENT_DATE)::int, EXTRACT(MONTH FROM CURRENT_DATE)::int, CURRENT_DATE, 1, NOW())
  ON CONFLICT (card_id, year, month)
  DO UPDATE SET 
    total_reads = card_read_stats.total_reads + 1,
    last_update = NOW();
  `,
      [iD]
    );

    // 3️⃣ Registar localização (opcional)
    if (lat && lon) {
      await pool.query(
        `
        INSERT INTO card_location (card_id, latitude, longitude, created_at)
        VALUES ($1, $2, $3, NOW())
        `,
        [iD, lat, lon]
      );
    }

    // 4️⃣ Montar objeto de resposta
    const card = {
      id: row.id,
      type: row.type,
      first_name: row.first_name,
      last_name: row.last_name,
      company: row.company,
      title: row.title,
      phone1: row.phone1,
      phone2: row.phone2,
      email: row.email,
      address: row.address,
      cover: row.cover,
      primary_color: row.primary_color,
      secondary_color: row.secondary_color,
      layout: row.layout,
      owner_id: row.owner_id,
      status: row.status,
      department: row.department,
      links: {
        review: row.review,
        facebook: row.facebook,
        standvirtual: row.standvirtual,
        website: row.website,
        instagram: row.instagram,
        olx: row.olx,
        location: row.location,
        linkedin: row.linkedin,
      },
    };

    res.json(card);
  } catch (err) {
    console.error("❌ Erro ao processar GET /cards/:iD:", err);
    next(err);
  }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// POST RQUESTS
//

// POST SINGLE CARD
//
/* router.post("/cards", isAuthenticated, hasPermission), async (req, res, next) => {
  try {
    const {
      id,
      type,
      first_name,
      last_name,
      company,
      title,
      phone1,
      phone2,
      email,
      address,
      cover,
      links,
      primary_color,
      secondary_color,
      layout,
      department,
      design_mode,
      design_meta
    } = req.body;

    const status = "pending";
    const ownerId = req.payload.id; // vem do JWT

    let finalDesignMeta = null;

if (design_meta) {
  finalDesignMeta =
    typeof design_meta === "string"
      ? JSON.parse(design_meta)
      : design_meta;
}


if (design_mode === "designed") {
  finalDesignMeta = design_meta ? JSON.parse(design_meta) : null;
}

if (design_mode === "uploaded") {
  if (!req.files?.front || !req.files?.back) {
    return res.status(400).json({
      message: "Front and back images are required for uploaded cards",
    });
  }

  const frontUpload = await cloudinary.uploader.upload(
    req.files.front[0].path
  );
  const backUpload = await cloudinary.uploader.upload(
    req.files.back[0].path
  );

  finalDesignMeta = {
    front: frontUpload.secure_url,
    back: backUpload.secure_url,
  };
}

    const insertCardQuery = `
  INSERT INTO business_cards (
    type, first_name, last_name, company, title,
    phone1, phone2, email, address, cover,
    primary_color, secondary_color, layout, owner_id, status, department, design_meta, design_mode
  ) VALUES (
    $1, $2, $3, $4, $5, $6,
    $7, $8, $9, $10, $11,
    $12, $13, $14, $15, $16, $17, $18
  ) RETURNING *;
`;

const cardValues = [
  type, first_name, last_name, company, title,
  phone1, phone2, email, address, cover,
  primary_color, secondary_color, layout, ownerId, status, department, finalDesignMeta ? JSON.stringify(finalDesignMeta) : null, design_mode
];


    const result = await pool.query(insertCardQuery, cardValues);
    const newCard = result.rows[0];

    if (links) {
      const {
        review, facebook, standvirtual, website,
        instagram, olx, location, linkedin,
      } = links;

      const insertLinksQuery = `
        INSERT INTO business_cards_links (
          business_card_id, review, facebook, standvirtual, website,
          instagram, olx, location, linkedin
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      `;

      await pool.query(insertLinksQuery, [
        newCard.id, review || null, facebook || null, standvirtual || null,
        website || null, instagram || null, olx || null, location || null, linkedin || null,
      ]);
    }

    res.status(201).json(newCard);
  } catch (error) {
    next(error);
  }
}; */

router.post(
  "/cards",
  isAuthenticated,
  hasPermission,
  async (req, res, next) => {
    try {
      const {
        id,
        type,
        first_name,
        last_name,
        company,
        title,
        phone1,
        phone2,
        email,
        address,
        cover,
        links,
        primary_color,
        secondary_color,
        layout,
        department,
        design_mode,
        design_meta,
      } = req.body;

      const status = "pending";
      const ownerId = req.payload.id;

      let finalDesignMeta = null;

      if (design_meta) {
        finalDesignMeta =
          typeof design_meta === "string"
            ? JSON.parse(design_meta)
            : design_meta;
      }

      const insertCardQuery = `
        INSERT INTO business_cards (
          type, first_name, last_name, company, title,
          phone1, phone2, email, address, cover,
          primary_color, secondary_color, layout,
          owner_id, status, department, design_meta, design_mode
        ) VALUES (
          $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,
          $11,$12,$13,$14,$15,$16,$17,$18
        )
        RETURNING *;
      `;

      const cardValues = [
        type,
        first_name,
        last_name,
        company,
        title,
        phone1,
        phone2,
        email,
        address,
        cover,
        primary_color,
        secondary_color,
        layout,
        ownerId,
        status,
        department,
        finalDesignMeta ? JSON.stringify(finalDesignMeta) : null,
        design_mode,
      ];

      const result = await pool.query(insertCardQuery, cardValues);
      const newCard = result.rows[0];

      if (links) {
        const {
          review,
          facebook,
          standvirtual,
          website,
          instagram,
          olx,
          location,
          linkedin,
        } = links;

        await pool.query(
          `
          INSERT INTO business_cards_links (
            business_card_id, review, facebook, standvirtual,
            website, instagram, olx, location, linkedin
          ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
        `,
          [
            newCard.id,
            review || null,
            facebook || null,
            standvirtual || null,
            website || null,
            instagram || null,
            olx || null,
            location || null,
            linkedin || null,
          ]
        );
      }

      res.status(201).json(newCard);
    } catch (error) {
      next(error);
    }
  }
);


// BULK POST
//
// POST criar vários cards em pack
/* router.post("/cards/bulk", isAuthenticated, hasPermission, async (req, res, next) => {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const { cards } = req.body;
    if (!Array.isArray(cards) || cards.length === 0) {
      await client.query("ROLLBACK");
      return res.status(400).json({ message: "Lista de cartões inválida" });
    }
    exportPdf()

    const createdCards = [];

    for (const card of cards) {
      const {
        id,
        type,
        first_name,
        last_name,
        company,
        title,
        phone1,
        phone2,
        email,
        address,
        cover,
        primary_color,
        secondary_color,
        layout,
        links
      } = card;

      const ownerId = req.payload.id;

      const insertCardQuery = `
        INSERT INTO business_cards (
          id, type, first_name, last_name, company, title,
          phone1, phone2, email, address, cover,
          primary_color, secondary_color, layout, owner_id
        ) VALUES (
          $1,$2,$3,$4,$5,$6,
          $7,$8,$9,$10,$11,
          $12,$13,$14,$15
        )
        RETURNING *;
      `;

      const cardValues = [
        id, type, first_name, last_name, company, title,
        phone1, phone2, email, address, cover,
        primary_color, secondary_color, layout, ownerId
      ];

      const result = await client.query(insertCardQuery, cardValues);
      const newCard = result.rows[0];

      if (links) {
        const {
          review, facebook, standvirtual, website,
          instagram, olx, location, linkedin
        } = links;

        const insertLinksQuery = `
          INSERT INTO business_cards_links (
            business_card_id, review, facebook, standvirtual, website,
            instagram, olx, location, linkedin
          )
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9);
        `;

        await client.query(insertLinksQuery, [
          newCard.id, review || null, facebook || null, standvirtual || null,
          website || null, instagram || null, olx || null, location || null, linkedin || null
        ]);
      }

      createdCards.push(newCard);
    }

    await client.query("COMMIT");
    res.status(201).json({ message: "Pack criado com sucesso", cards: createdCards });

  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Erro no bulk insert:", error);
    res.status(500).json({ message: "Erro ao criar pack", error: error.message });
  } finally {
    client.release();
  }
}); */

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// PUT
//
router.put(
  "/cards/:id",
  isAuthenticated,
  hasPermission,
  async (req, res, next) => {
    const client = await pool.connect();

    try {
      await client.query("BEGIN");

      const { id } = req.params;
      const {
        type,
        first_name,
        last_name,
        company,
        title,
        phone1,
        phone2,
        email,
        address,
        cover,
        links,
        primary_color,
        secondary_color,
        layout,
        department,
      } = req.body;

      // Se for gestor, só pode editar os seus
      let checkQuery = "SELECT owner_id FROM business_cards WHERE id = $1";
      const checkRes = await client.query(checkQuery, [id]);
      if (checkRes.rows.length === 0) {
        await client.query("ROLLBACK");
        return res.status(404).json({ message: "Card not found" });
      }

      const cardOwner = checkRes.rows[0].owner_id;
      if (req.payload.type === "gestor" && cardOwner !== req.payload.id) {
        await client.query("ROLLBACK");
        return res
          .status(403)
          .json({ message: "Not allowed to edit this card" });
      }

      const updateCardQuery = `
      UPDATE business_cards
      SET type = $1, first_name = $2, last_name = $3, company = $4, title = $5,
          phone1 = $6, phone2 = $7, email = $8, address = $9, cover = $10,
          primary_color = $11, secondary_color = $12, layout = $13, department = $14
      WHERE id = $15
      RETURNING *;
    `;
      const cardValues = [
        type,
        first_name,
        last_name,
        company,
        title,
        phone1,
        phone2,
        email,
        address,
        cover,
        primary_color,
        secondary_color,
        layout,
        department,
        id,
      ];

      const updatedCardResult = await client.query(updateCardQuery, cardValues);

      if (updatedCardResult.rows.length === 0) {
        await client.query("ROLLBACK");
        return res.status(404).json({ message: "Card not found" });
      }
      const updatedCard = updatedCardResult.rows[0];

      if (links) {
        const {
          review,
          facebook,
          standvirtual,
          website,
          instagram,
          olx,
          location,
          linkedin,
        } = links;

        const upsertLinksQuery = `
        INSERT INTO business_cards_links (
          business_card_id, review, facebook, standvirtual, website,
          instagram, olx, location, linkedin
        ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
        ON CONFLICT (business_card_id) DO UPDATE SET
          review = EXCLUDED.review,
          facebook = EXCLUDED.facebook,
          standvirtual = EXCLUDED.standvirtual,
          website = EXCLUDED.website,
          instagram = EXCLUDED.instagram,
          olx = EXCLUDED.olx,
          location = EXCLUDED.location,
          linkedin = EXCLUDED.linkedin;
      `;
        const linkValues = [
          id,
          review || null,
          facebook || null,
          standvirtual || null,
          website || null,
          instagram || null,
          olx || null,
          location || null,
          linkedin || null,
        ];

        await client.query(upsertLinksQuery, linkValues);
      }

      await client.query("COMMIT");
      res.status(200).json({ ...updatedCard, links: links || {} });
    } catch (error) {
      await client.query("ROLLBACK");
      next(error);
    } finally {
      client.release();
    }
  }
);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// DELETE
//
router.delete(
  "/cards/:id",
  isAuthenticated,
  hasPermission,
  async (req, res, next) => {
    try {
      const { id } = req.params;

      // Verifica se existe e de quem é
      const checkRes = await pool.query(
        "SELECT owner_id FROM business_cards WHERE id = $1",
        [id]
      );
      if (checkRes.rows.length === 0) {
        return res.status(404).json({ message: "Card not found" });
      }

      const cardOwner = checkRes.rows[0].owner_id;
      if (req.payload.type === "gestor" && cardOwner !== req.payload.id) {
        return res
          .status(403)
          .json({ message: "Not allowed to delete this card" });
      }

      await pool.query("DELETE FROM business_cards WHERE id = $1", [id]);
      res.status(200).json({ message: "This card was deleted" });
    } catch (error) {
      next(error);
    }
  }
);

// IMAGE UPLOAD
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// POST IMAGE
//
// request que edita insere e atualiza a imagem do cartão - COVER

router.post(
  "/upload/image",
  isAuthenticated,
  hasPermission,
  upload.single("image"),
  async (req, res, next) => {
    try {
      if (!req.file?.path) {
        return res.status(400).json({ message: "Nenhuma imagem enviada" });
      }

      // Upload para o Cloudinary
      const result = await cloudinary.uploader.upload(req.file.path);
      const imageUrl = result.secure_url;


      const { cardId } = req.body; // ou req.query.cardId se vier como query parameter

      if (!cardId) {
        return res.status(400).json({ message: "ID do card é obrigatório" });
      }

      // Query para atualizar o campo cover na base de dados
      const updateCoverQuery = `
      UPDATE business_cards 
      SET cover = $1 
      WHERE id = $2 
      RETURNING *;
    `;

      const updatedCard = await pool.query(updateCoverQuery, [
        imageUrl,
        cardId,
      ]);

      if (updatedCard.rows.length === 0) {
        return res.status(404).json({ message: "Card não encontrado" });
      }

      res.json({
        url: imageUrl,
        card: updatedCard.rows[0],
        message: "Imagem carregada e card atualizado com sucesso",
      });
    } catch (error) {
      console.error("Erro no upload:", error);
      next(error);
    }
  }
);

// PDF CARDS DESIGN
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// PDF SEND
//
// request que edita insere e atualiza a imagem do cartão - COVER

router.post("/send-pdfs", upload.array("pdfs"), async (req, res) => {
  try {
    const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, EMAIL_FROM } =
      process.env;

    const data = JSON.parse(req.body.data || "{}");
    const pdfFiles = req.files || [];


    // Cria transporter SMTP (Gmail)
    const transporter = nodemailer.createTransport({
      host: SMTP_HOST,
      port: SMTP_PORT,
      secure: true,
      auth: {
        user: SMTP_USER,
        pass: SMTP_PASS,
      },
    });

    // Email com anexos
    const mailOptions = {
      from: `"NFC-ME" <${EMAIL_FROM}>`,
      to: "suporte@nfc-me.pt",
      subject: `📇 Novo pack de ${pdfFiles.length} cartões - ${
        data.cards?.[0]?.company || "Cliente"
      }`,
      text: "Segue em anexo o pack de cartões criados no checkout.",
      attachments: pdfFiles.map((file) => ({
        filename: file.originalname,
        content: file.buffer,
      })),
    };

    await transporter.sendMail(mailOptions);

    // (Opcional) guardar os dados na BD
    // await Card.bulkCreate(data.cards);

    res.json({ message: "PDFs recebidos e email enviado com sucesso!" });
  } catch (error) {
    console.error("❌ Erro ao enviar email:", error);
    res.status(500).json({ error: "Falha no envio do email" });
  }
});

// POST RECEIVE PDFS

router.post(
  "/cards/print",
  isAuthenticated,
  upload.any(),
  async (req, res) => {
    const cards = [];

    Object.keys(req.body).forEach(key => {
      if (key.startsWith("cards")) {
        const [, index, field] = key.match(/cards\[(\d+)\]\[(\w+)\]/);

        cards[index] ||= {};
        cards[index][field] =
          field === "design"
            ? JSON.parse(req.body[key])
            : req.body[key];
      }
    });

    // req.files contains images
    // Map images → card index
    // Generate PDFs
    // Email printer

    res.json({ success: true });
  }
);

router.post(
  "/cards/upload-design",
  upload.fields([
    { name: "front", maxCount: 1 },
    { name: "back", maxCount: 1 },
  ]),
  async (req, res, next) => {
    try {
      if (!req.files?.front || !req.files?.back) {
        return res.status(400).json({
          message: "Front and back files are required",
        });
      }

      // Upload to Cloudinary
      const frontUpload = await cloudinary.uploader.upload(
        req.files.front[0].path
      );
      const backUpload = await cloudinary.uploader.upload(
        req.files.back[0].path
      );

      res.json({
        frontUrl: frontUpload.secure_url,
        backUrl: backUpload.secure_url,
      });
    } catch (err) {
      console.error("❌ upload-design error:", err);
      next(err);
    }
  }
);


module.exports = router;
